package com.jpa.example.storedproc.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureParameter;

@Entity
@NamedStoredProcedureQuery( 
		 name = "getLocation",
		 procedureName = "getLocation", 
		 parameters = {
		 @StoredProcedureParameter(mode = ParameterMode.IN, type = String.class, name = "p_name"),
		 @StoredProcedureParameter(mode = ParameterMode.OUT, type = String.class, name = "p_loc") })

public class Company {

	public void setLoc(String loc) {
		this.loc = loc;
	}

	public String getLoc() {
		return loc;
	}
	@Id
	private String loc;
	
}
