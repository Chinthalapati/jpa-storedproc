package com.jpa.example.storedproc.repository;

import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.jpa.example.storedproc.model.Company;

public interface CompanyRepository extends CrudRepository<Company,String>{

	@Procedure(name="getLocation")
	String getLocation(@Param("p_name") String p_name);
}
