package com.jpa.example.storedproc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.jpa.example.storedproc.repository.CompanyRepository;

@SpringBootApplication
public class StoredprocApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(StoredprocApplication.class, args);
	}

	@Autowired
	CompanyRepository crepo;
	
	@Override
	public void run(String... arg0) throws Exception {
		// TODO Auto-generated method stub
		String loc = crepo.getLocation("IBM");
		System.out.println("Stored Procedure Output :: " + loc);
		
	}
}
